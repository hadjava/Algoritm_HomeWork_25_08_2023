import java.util.ArrayList;
import java.util.List;

class Elevator {
    private String name;
    private int currentFloor;

    public Elevator(String name, int currentFloor) {
        this.name = name;
        this.currentFloor = currentFloor;
    }

    public String getName() {
        return name;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void moveToFloor(int floor) {
        System.out.println(name + " is moving to floor " + floor);
        currentFloor = floor;
    }
}

public class ElevatorController {
    private List<Elevator> elevators;

    public ElevatorController(List<Elevator> elevators) {
        this.elevators = elevators;
    }

    public Elevator getClosestElevator(int floor) {
        Elevator closestElevator = null;
        int minDistance = Integer.MAX_VALUE;

        for (Elevator elevator : elevators) {
            int distance = Math.abs(elevator.getCurrentFloor() - floor);
            if (distance < minDistance) {
                minDistance = distance;
                closestElevator = elevator;
            }
        }

        return closestElevator;
    }

    public static void main(String[] args) {
        // Пример использования
        List<Elevator> elevators = new ArrayList<>();
        elevators.add(new Elevator("A", 0));
        elevators.add(new Elevator("B", 8));

        ElevatorController elevatorController = new ElevatorController(elevators);

        // Вызов лифта на этаж 1
        int floorToCall = 1;
        Elevator closestElevator = elevatorController.getClosestElevator(floorToCall);
        closestElevator.moveToFloor(floorToCall);
    }
}